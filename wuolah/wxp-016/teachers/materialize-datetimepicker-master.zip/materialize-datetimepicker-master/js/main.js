$(document).ready(function () {
    M.AutoInit();
    var DateField = MaterialDateTimePicker.create($('#datetime'))
});
