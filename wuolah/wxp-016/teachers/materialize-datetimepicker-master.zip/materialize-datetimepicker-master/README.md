# materialize-datetimepicker
Custom handled DateTime Picker for Materialize CSS based on Materialize v1.0.0-rc.1 (http://materializecss.com)

# Simple Usage
Simply add jQuery, Materialize & MaterializeDateTimePicker to your site and write this;

![alt usage](https://raw.githubusercontent.com/fawadtariq/materialize-datetimepicker/master/img/usage-capture.PNG)

# Example

[Click Here](https://fawadtariq.github.io/materialize-datetimepicker/)
